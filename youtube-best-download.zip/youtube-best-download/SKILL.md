---
name: youtube-best-download
description: Download YouTube videos from youtube.com/youtu.be links using yt-dlp. Trigger when the user shares a YouTube URL or asks to download/save YouTube videos to phone storage. Defaults to highest quality first, prefer MP4/M4A when available but do not sacrifice quality for MP4; uses cookies for age-restricted videos if available; copies output to mounted phone folder under /var/minis/mounts and can delete the Minis workspace copy.
version: 1.0.0
---
# YouTube Best Download

Use this skill whenever the user shares a YouTube link and wants it downloaded/saved.

## Policy / preference

- Default quality strategy: **highest quality first, prefer MP4 but do not force MP4 at the cost of quality**.
- yt-dlp format selector:
  ```bash
  -f "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/best"
  ```
- Add `--merge-output-format mp4` so compatible streams become MP4; if the true best streams are not MP4-compatible, accept `.webm`/`.mkv` as needed.
- Use YouTube cookies when present, especially for age-restricted videos. Default cookie path used by the script:
  `/var/minis/attachments/uploads/shared-c02eab22.txt`
- After download, copy the file to the user's mounted phone folder under `/var/minis/mounts/`.
- Unless the user asks to keep both copies, delete the Minis workspace copy after successful phone copy to save space.

## Fast path

Run:

```bash
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py 'YOUTUBE_URL'
```

The script will:
1. Ensure `yt-dlp`, `ffmpeg`, and `nodejs` exist.
2. Use Node + yt-dlp remote EJS solver for current YouTube JS challenges:
   `--js-runtimes node --remote-components ejs:github`
3. Use cookies if the default cookies file exists.
4. Download into `/var/minis/workspace/youtube_downloads/`.
5. Copy to the first mounted folder under `/var/minis/mounts/`.
6. Delete the workspace output by default.

Useful options:

```bash
# Keep Minis workspace copy too
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py URL --keep-workspace

# Download only, do not copy to phone
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py URL --no-copy

# Specify a mounted folder name/path
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py URL --mount minis
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py URL --mount /var/minis/mounts/minis

# Specify another cookies file
python3 /var/minis/skills/youtube-best-download/scripts/youtube_best_download.py URL --cookies /path/to/cookies.txt
```

## If no mount exists

Tell the user to mount a phone folder:
[挂载外部文件夹](minis://settings/mount-external)

Then rerun the script or manually copy from workspace to `/var/minis/mounts/<name>/`.

## Manual fallback

If the script is not appropriate, use this command pattern:

```bash
mkdir -p /var/minis/workspace/youtube_downloads
yt-dlp --cookies /path/to/cookies.txt \
  --js-runtimes node --remote-components ejs:github \
  --no-playlist \
  -f 'bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/best' \
  --merge-output-format mp4 \
  -o '/var/minis/workspace/youtube_downloads/%(title).120s [%(id)s].%(ext)s' \
  'YOUTUBE_URL'
```

Then copy the result to `/var/minis/mounts/<mounted-folder>/` and remove the workspace copy if requested.
