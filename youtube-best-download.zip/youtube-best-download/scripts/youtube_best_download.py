#!/usr/bin/env python3
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

WORKDIR = Path('/var/minis/workspace/youtube_downloads')
DEFAULT_COOKIES = Path('/var/minis/attachments/uploads/shared-c02eab22.txt')
MOUNTS = Path('/var/minis/mounts')
FORMAT = 'bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/best'


def run(cmd, check=True):
    print('+ ' + ' '.join(str(x) for x in cmd), flush=True)
    p = subprocess.run(cmd, text=True)
    if check and p.returncode != 0:
        sys.exit(p.returncode)
    return p.returncode


def ensure_tool(name, apk=None):
    if shutil.which(name):
        return
    if apk:
        run(['apk', 'add', apk])
    if not shutil.which(name):
        print(f'ERROR: missing tool {name}', file=sys.stderr)
        sys.exit(127)


def first_mount():
    if not MOUNTS.exists():
        return None
    dirs = [p for p in MOUNTS.iterdir() if p.is_dir()]
    if not dirs:
        return None
    # Prefer non-empty names only; stable sorted order.
    return sorted(dirs, key=lambda p: p.name)[0]


def main():
    ap = argparse.ArgumentParser(description='Download YouTube at best quality, prefer MP4, copy to mounted phone folder.')
    ap.add_argument('url')
    ap.add_argument('--cookies', default=str(DEFAULT_COOKIES), help='Netscape cookies.txt path')
    ap.add_argument('--mount', default='', help='Destination mounted folder under /var/minis/mounts or absolute path')
    ap.add_argument('--keep-workspace', action='store_true', help='Keep workspace copy after copying to phone')
    ap.add_argument('--no-copy', action='store_true', help='Only download to workspace')
    args = ap.parse_args()

    ensure_tool('yt-dlp', 'yt-dlp')
    ensure_tool('ffmpeg', 'ffmpeg')
    if not shutil.which('node'):
        run(['apk', 'add', 'nodejs'])

    WORKDIR.mkdir(parents=True, exist_ok=True)
    before = set(WORKDIR.glob('*'))

    cmd = [
        'yt-dlp',
        '--js-runtimes', 'node',
        '--remote-components', 'ejs:github',
        '--no-playlist',
        '-f', FORMAT,
        '--merge-output-format', 'mp4',
        '-o', str(WORKDIR / '%(title).120s [%(id)s].%(ext)s'),
    ]
    cpath = Path(args.cookies)
    if cpath.exists():
        cmd[1:1] = ['--cookies', str(cpath)]
    cmd.append(args.url)
    run(cmd)

    after = set(WORKDIR.glob('*'))
    new_files = sorted([p for p in after - before if p.is_file()], key=lambda p: p.stat().st_mtime)
    if not new_files:
        # fallback: latest media file
        exts = {'.mp4', '.mkv', '.webm', '.m4a', '.mp3'}
        new_files = sorted([p for p in WORKDIR.iterdir() if p.is_file() and p.suffix.lower() in exts], key=lambda p: p.stat().st_mtime)[-1:]
    if not new_files:
        print('ERROR: download finished but no output file found', file=sys.stderr)
        sys.exit(1)

    output = new_files[-1]
    print(f'WORKSPACE_FILE={output}')
    print(f'SIZE={output.stat().st_size}')

    if args.no_copy:
        return

    if args.mount:
        dest_dir = Path(args.mount)
        if not dest_dir.is_absolute():
            dest_dir = MOUNTS / args.mount
    else:
        dest_dir = first_mount()

    if not dest_dir or not dest_dir.exists():
        print('NO_MOUNT_FOUND: file kept in workspace. Mount a phone folder in Settings → Mount External Folders.', file=sys.stderr)
        return

    safe_name = output.name
    # Remove YouTube id from copied phone filename for readability when possible.
    import re
    safe_name = re.sub(r' \[[A-Za-z0-9_-]{11}\](?=\.[^.]+$)', '', safe_name)
    dest = dest_dir / safe_name
    shutil.copy2(output, dest)
    print(f'PHONE_FILE={dest}')
    print(f'PHONE_SIZE={dest.stat().st_size}')

    if not args.keep_workspace:
        output.unlink()
        try:
            WORKDIR.rmdir()
        except OSError:
            pass
        print('WORKSPACE_DELETED=1')


if __name__ == '__main__':
    main()
